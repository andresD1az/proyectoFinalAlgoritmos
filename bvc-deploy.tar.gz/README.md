# 📈 BVC Analytics — Plataforma de Análisis Financiero

> Plataforma de análisis financiero cuantitativo construida **desde cero**, sin NumPy, pandas, scikit-learn ni ninguna librería de cálculo matemático. Todos los algoritmos están implementados manualmente en Python puro.

---

## 🏗️ Arquitectura del Sistema

```
bvc-analytics/
│
├── 📊 etl/                     # Capa de Datos
│   ├── downloader.py           #   Descarga HTTP pura (urllib)
│   ├── cleaner.py              #   Limpieza: Interpolación lineal + Z-Score
│   └── database.py             #   Acceso a PostgreSQL (psycopg2)
│
├── 🧮 algorithms/              # Capa Algorítmica (NÚCLEO)
│   ├── similarity.py           #   4 algoritmos de similitud
│   ├── patterns.py             #   Detección de patrones (ventana deslizante)
│   └── volatility.py           #   Riesgo: Volatilidad, VaR, Sharpe
│
├── 🔐 auth/                    # Autenticación
│   └── auth.py                 #   Hash SHA-256, sesiones, tokens
│
├── 🎓 cms/                     # Contenido Educativo
│   └── content.py              #   Lecciones, simulador de paper trading
│
├── 🌐 api/                     # Servidor HTTP
│   └── server.py               #   http.server (stdlib) sin Flask/Django
│
├── 📄 reports/                 # Generación de Reportes
│   └── generator.py            #   JSON + TXT desde los 4 módulos
│
├── 🖥️ frontend/
│   └── index.html              #   SPA completa (SVG + Canvas API) sin frameworks
│
├── 🗄️ database/
│   └── init.sql                #   Esquema PostgreSQL
│
├── main.py                     # Orquestador: etl | similitud | volatilidad | todo
├── config.py                   # Variables de configuración
├── docker-compose.yml          # Orquestación Docker
└── Dockerfile                  # Imagen Python 3.11-slim
```

---

## 🧮 Algoritmos Implementados (16 en total)

> **Principio fundamental:** Ningún algoritmo usa `numpy`, `pandas`, `scipy`, `sklearn` ni ninguna librería matemática de alto nivel. Solo se usa la librería estándar de Python (`math`, `statistics`, `collections`, etc.).

### Módulo 1: ETL — `etl/cleaner.py`

#### 1. Interpolación Lineal `O(n)`
**Ubicación:** `etl/cleaner.py` → función `_interpolar_nulos()`

Cuando Yahoo Finance devuelve días sin negociación (`None`), se rellena el hueco interpolando entre el valor anterior y el siguiente.

```
Fórmula:
  v(t) = v(t-1) + (v(t+1) - v(t-1)) / 2

Para secuencias más largas:
  v(t+k) = v(t) + k * (v(t+n) - v(t)) / n
```
- **Complejidad:** O(n) — un solo barrido de la serie
- **Justificación:** Preserva la tendencia sin distorsionar los datos

#### 2. Z-Score para Outliers `O(n)`
**Ubicación:** `etl/cleaner.py` → función `detectar_outliers_zscore()`

Detecta y elimina precios anómalos causados por errores de datos (ej. splits no ajustados).

```
Fórmula:
  z = (x - μ) / σ
  Si |z| > umbral (default=3.5), el precio es outlier
```
- **Complejidad:** O(n) — calcula μ y σ manualmente en un barrido
- **Sin `statistics.stdev`** — todo calculado con sumas manuales

---

### Módulo 2: Similitud — `algorithms/similarity.py`

#### 3. Distancia Euclidiana `O(n)`
**Ubicación:** `algorithms/similarity.py` → función `distancia_euclidiana()`

Mide la distancia geométrica entre dos series de precios normalizadas.

```
Fórmula:
  d(A, B) = √( Σᵢ (Aᵢ - Bᵢ)² )

Preprocesamiento (Min-Max, también implementado aquí):
  x_norm = (x - min) / (max - min)
```
- **Complejidad:** O(n)
- **Resultado:** 0 = series idénticas, mayor valor = más diferentes

#### 4. Correlación de Pearson `O(n)`
**Ubicación:** `algorithms/similarity.py` → función `correlacion_pearson()`

Mide la relación lineal entre dos series. El más usado en finanzas para medir co-movimiento.

```
Fórmula:
  r = Σ((Aᵢ - Ā)(Bᵢ - B̄))
      ─────────────────────────────────
      √(Σ(Aᵢ - Ā)² · Σ(Bᵢ - B̄)²)

  Ā = Σ(Aᵢ)/n  (media manual)
```
- **Complejidad:** O(n)
- **Resultado:** [-1, 1] donde 1 = correlación perfecta, -1 = inversa perfecta

#### 5. Similitud por Coseno `O(n)`
**Ubicación:** `algorithms/similarity.py` → función `similitud_coseno()`

Trata las series como vectores en ℝⁿ y mide el ángulo. Invariante a la magnitud.

```
Fórmula:
  cos(θ) = (A · B) / (‖A‖ · ‖B‖)
           = Σ(Aᵢ·Bᵢ) / (√Σ(Aᵢ²) · √Σ(Bᵢ²))
```
- **Complejidad:** O(n)
- **Ventaja:** No le afecta que EC cotice en miles de pesos y SPY en dólares

#### 6. DTW — Dynamic Time Warping `O(n·k)` con Ventana Sakoe-Chiba
**Ubicación:** `algorithms/similarity.py` → función `dtw()`

El algoritmo más sofisticado: permite comparar series desfasadas en el tiempo. Si Bancolombia sube 3 días después que Ecopetrol, lo detecta como similar.

```
Recurrencia (Programación Dinámica):
  DTW[0][0] = 0
  DTW[i][j] = |aᵢ - bⱼ| + min(
                  DTW[i-1][j],     ← inserción
                  DTW[i][j-1],     ← eliminación
                  DTW[i-1][j-1]    ← coincidencia diagonal
               )

Optimización Sakoe-Chiba (banda diagonal):
  Solo computa j ∈ [max(1, i-w), min(m, i+w)]
  donde w = n * 0.10  (ventana del 10%)

  Esto reduce O(n²) → O(n·k) con k = ventana restrictiva
```
- **Sin optimización:** ~1,254² = 1,572,516 operaciones por par
- **Con ventana 10%:** ~1,254×125 = 156,750 operaciones por par (**10× más rápido**)

---

### Módulo 3: Patrones — `algorithms/patterns.py`

#### 7. Ventana Deslizante `O(n·k)`
**Ubicación:** `algorithms/patterns.py` → función `detectar_patrones()`

Barrido de la serie usando una ventana de k días, clasificando cada segmento.

```
Para cada segmento [i, i+k]:
  variación = (precio_final - precio_inicial) / precio_inicial × 100
  patrón = clasificar_segmento(segmento)

Clasificaciones:
  > +2%  → tendencia_alcista
  < -2%  → tendencia_bajista
  rebote → mínimo seguido de recuperación ≥1%
  consolidación → variación < 1%
```
- **Complejidad:** O(n·k) donde k = tamaño de la ventana (default: 5 días)

#### 8. Detección de Picos y Valles `O(n)`
**Ubicación:** `algorithms/patterns.py` → función `detectar_picos_valles()`

Identifica máximos y mínimos locales usando un vecindario de ±radio días.

```
Un punto i es pico   si: precio[i] = max(precio[i-r : i+r+1])
Un punto i es valle  si: precio[i] = min(precio[i-r : i+r+1])
```
- **Complejidad:** O(n) — barrido único con ventana local

#### 9. Media Móvil Simple (SMA) `O(n·k)`
**Ubicación:** `algorithms/patterns.py` → función `media_movil_simple()`

Suaviza la serie de precios promediando los últimos k días.

```
Fórmula:
  SMA(t, k) = (p[t] + p[t-1] + ... + p[t-k+1]) / k
```
- **Complejidad:** O(n·k)
- **Uso:** Base para detectar Golden Cross y Death Cross

#### 10. Golden Cross / Death Cross `O(n)`
**Ubicación:** `algorithms/patterns.py` → función `detectar_cruces_medias()`

Detecta los dos patrones más famosos del análisis técnico.

```
Golden Cross (señal alcista):
  SMA_corta[i-1] ≤ SMA_larga[i-1]  Y  SMA_corta[i] > SMA_larga[i]

Death Cross (señal bajista):
  SMA_corta[i-1] ≥ SMA_larga[i-1]  Y  SMA_corta[i] < SMA_larga[i]
```
- **Complejidad:** O(n) — un barrido una vez calculadas las SMAs

---

### Módulo 4: Volatilidad y Riesgo — `algorithms/volatility.py`

#### 11. Rendimientos Logarítmicos `O(n)`
**Ubicación:** `algorithms/volatility.py` → función `calcular_retornos_log()`

Los rendimientos log son más robustos que los porcentuales para series largas.

```
Fórmula:
  r(t) = ln(p(t) / p(t-1))  = math.log(p[t] / p[t-1])

Ventaja frente a rendimiento simple:
  Los cambios son aditivos: r_total = Σ r(t)
```
- **Complejidad:** O(n) — usa `math.log` (stdlib), no `numpy.log`

#### 12. Volatilidad Histórica Anualizada `O(n)`
**Ubicación:** `algorithms/volatility.py` → función `calcular_volatilidad()`

Desviación estándar de los rendimientos, anualizada por convención de mercado.

```
Fórmula:
  σ_diaria = √( Σ(rᵢ - r̄)² / (n-1) )   ← std. dev. manual (Bessel)
  σ_anual  = σ_diaria × √252             ← 252 días de trading/año
```
- **Sin `statistics.stdev`** — implementado manualmente con corrección de Bessel
- **Complejidad:** O(n)

#### 13. Máximo Drawdown `O(n)`
**Ubicación:** `algorithms/volatility.py` → función `calcular_max_drawdown()`

Mide la mayor caída desde un pico histórico. El indicador de riesgo más intuitivo.

```
Algoritmo:
  pico_actual = precio[0]
  para cada precio p:
    si p > pico_actual: actualizar pico_actual
    drawdown = (pico_actual - p) / pico_actual
    max_drawdown = max(max_drawdown, drawdown)
```
- **Complejidad:** O(n) — un solo barrido manteniendo el máximo acumulado

#### 14. VaR Histórico `O(n log n)`
**Ubicación:** `algorithms/volatility.py` → función `calcular_var_historico()`

Value at Risk: la pérdida máxima esperada para un nivel de confianza dado.

```
Método Histórico (no paramétrico):
  1. Calcular rendimientos diarios: r[t] = (p[t] - p[t-1]) / p[t-1]
  2. Ordenar rendimientos de menor a mayor: O(n log n)
  3. El percentil 5% (conf 95%) es el VaR

Ejemplo:
  VaR 95% = -2.3% → hay 5% de probabilidad de perder más de 2.3% en un día
```
- **Ordenamiento:** `list.sort()` (Timsort, stdlib) — **sin numpy.percentile**
- **Complejidad:** O(n log n) por el ordenamiento

#### 15. Sharpe Ratio `O(n)`
**Ubicación:** `algorithms/volatility.py` → función `calcular_sharpe()`

Rentabilidad ajustada por riesgo. El indicador más usado para comparar portafolios.

```
Fórmula:
  Sharpe = (R_p - R_f) / σ_p

  R_p = retorno promedio del activo (manual: Σ rᵢ / n)
  R_f = tasa libre de riesgo (default: 0.02 = 2% anual)
  σ_p = volatilidad anualizada del activo
```
- **Interpretación:** >1 excelente, >0 aceptable, <0 peor que el bono libre de riesgo
- **Complejidad:** O(n)

#### 16. Clasificación de Riesgo
**Ubicación:** `api/server.py` → método `_clasificacion_riesgo()`

Categoriza activos usando la volatilidad anualizada como criterio.

```
Categorías (estándar de mercado):
  Conservador → σ_anual < 15%
  Moderado    → 15% ≤ σ_anual < 30%
  Agresivo    → σ_anual ≥ 30%
```

---

## 🚀 Instalación y Ejecución

### Prerrequisitos
- Docker Desktop instalado y corriendo
- No requiere Python local ni PostgreSQL local

### Pasos

```bash
# 1. Clonar el repositorio
git clone <url-repo>
cd proyect-final

# 2. Configurar variables de entorno
cp .env.example .env
# (Editar .env si se necesita cambiar credenciales)

# 3. Levantar los servicios
docker-compose up --build -d

# 4. Ejecutar el pipeline completo de datos
docker-compose exec bvc_api python main.py todo

# 5. Abrir el Dashboard
# Navegar a http://localhost:8001
```

### Modos de ejecución de `main.py`

```bash
# Descarga y limpia datos (ETL)
docker-compose exec bvc_api python main.py etl

# Calcula los 4 algoritmos de similitud (190 pares)
docker-compose exec bvc_api python main.py similitud

# Calcula volatilidad, VaR y Sharpe para los 20 activos
docker-compose exec bvc_api python main.py volatilidad

# Ejecuta todo en secuencia
docker-compose exec bvc_api python main.py todo

# Inicia solo el servidor API
docker-compose exec bvc_api python main.py api
```

---

## 🌐 API REST — Endpoints

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/health` | Estado del sistema |
| GET | `/activos` | Lista de activos en la BD |
| POST | `/activos/agregar` | Agrega un nuevo activo de Yahoo Finance |
| GET | `/precios?ticker=SPY&columna=cierre` | Precios históricos |
| GET | `/precios/ohlcv?ticker=SPY&n=120` | OHLCV completo para velas |
| GET | `/similitud?algoritmo=pearson` | Resultados de similitud |
| GET | `/volatilidad?ticker=SPY` | Métricas de volatilidad |
| GET | `/patrones?ticker=SPY` | Patrones detectados |
| GET | `/patrones/cruces?ticker=SPY` | Golden/Death Cross |
| GET | `/riesgo?ticker=SPY` | VaR, Sharpe, Drawdown |
| GET | `/riesgo/clasificacion` | Ranking de riesgo todos los activos |
| GET | `/correlacion/matriz` | Matriz 20×20 de correlaciones |
| GET | `/reporte` | Reporte técnico en JSON |
| GET | `/reporte/txt` | Reporte técnico en texto plano |
| POST | `/auth/register` | Registro de usuario |
| POST | `/auth/login` | Inicio de sesión |
| POST | `/auth/logout` | Cierre de sesión |
| GET | `/auth/me` | Usuario actual |
| GET | `/academia/lecciones` | Lista de lecciones educativas |
| GET | `/academia/leccion?id=1` | Contenido de una lección |
| GET | `/simulador/portafolio` | Portafolio virtual del usuario |
| POST | `/simulador/comprar` | Comprar activo (dinero virtual) |
| POST | `/simulador/vender` | Vender activo (dinero virtual) |

---

## 🛠️ Stack Tecnológico

| Capa | Tecnología | Por qué |
|------|-----------|---------|
| **Lenguaje** | Python 3.11 | Legible, stdlib poderosa |
| **Base de Datos** | PostgreSQL 15 | ACID, soporte series numéricas |
| **Servidor API** | `http.server` (stdlib) | Sin Flask, sin Django |
| **Frontend** | HTML5 + CSS3 + JS (vanilla) | Sin React, sin Vue |
| **Gráficos** | SVG + Canvas API | Sin Chart.js, sin D3.js |
| **Contenedor** | Docker + Docker Compose | Reproducibilidad total |
| **Auth** | `hashlib` + `secrets` (stdlib) | Sin JWT, sin bcrypt |

---

## 📚 Restricción Académica: "Zero External Libraries"

Las únicas dependencias en `requirements.txt` son:

```
psycopg2-binary   # Conector PostgreSQL (driver de BD, no de lógica)
```

Librerías **explícitamente prohibidas y no usadas:**
- ❌ `pandas` — DataFrames
- ❌ `numpy` — Álgebra lineal
- ❌ `scipy` — Estadística
- ❌ `scikit-learn` — Machine Learning
- ❌ `yfinance` — Datos financieros empaquetados
- ❌ `flask`, `fastapi`, `django` — Frameworks web
- ❌ `matplotlib`, `plotly`, `seaborn` — Gráficos

---

## 🏦 Mercados Oficiales

| Mercado | País | URL |
|---------|------|-----|
| Bolsa de Valores de Colombia (BVC) | 🇨🇴 | [https://www.bvc.com.co](https://www.bvc.com.co) |
| New York Stock Exchange (NYSE) | 🇺🇸 | [https://www.nyse.com](https://www.nyse.com) |
| NASDAQ | 🇺🇸 | [https://www.nasdaq.com](https://www.nasdaq.com) |
| Yahoo Finance | Global | [https://finance.yahoo.com](https://finance.yahoo.com) |
| Bloomberg | Global | [https://www.bloomberg.com/markets](https://www.bloomberg.com/markets) |
| Investing.com | Global | [https://es.investing.com](https://es.investing.com) |
| TradingView | Global | [https://www.tradingview.com](https://www.tradingview.com) |
| Superintendencia Financiera (Colombia) | 🇨🇴 | [https://www.superfinanciera.gov.co](https://www.superfinanciera.gov.co) |

---

## 📖 Glosario de Términos Clave

| Término | Definición |
|---------|-----------|
| **OHLCV** | Open, High, Low, Close, Volume — datos básicos de una sesión bursátil |
| **SMA** | Simple Moving Average — promedio de los últimos N días |
| **Golden Cross** | SMA corta cruza SMA larga hacia arriba → señal alcista |
| **Death Cross** | SMA corta cruza SMA larga hacia abajo → señal bajista |
| **VaR** | Value at Risk — pérdida máxima esperada con X% de confianza |
| **Sharpe Ratio** | Rentabilidad extra sobre el activo libre de riesgo, por unidad de riesgo |
| **Drawdown** | Caída porcentual desde el pico histórico hasta el valor actual |
| **DTW** | Dynamic Time Warping — comparación de series con desfase temporal |
| **Pairs Trading** | Estrategia: comprar el activo que rezagó y vender el que lideró |

---

*Proyecto académico — Análisis de Algoritmos — Ingeniería de Sistemas*
